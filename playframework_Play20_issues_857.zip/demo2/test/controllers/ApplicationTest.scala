package controllers

import org.junit.Test
import scala.concurrent.Await
import scala.concurrent.duration.DurationInt
import org.junit.Assert._
import play.api.test._
import play.api.test.Helpers._
import play.api.mvc._
import java.util.concurrent.CountDownLatch
import scala.concurrent.ExecutionContext.Implicits.global
import org.junit.Before
import scala.concurrent.duration.Duration
import backend.SomeRepository

class ApplicationTest {

    @Test
    def testAsyncPost {

        new WithApplication {

            //setup input
            val request = FakeRequest(POST, "/someAsync").
                withSession(Security.username -> "lana@hippodrome-london.com").
                withHeaders("content-type" -> "application/x-www-form-urlencoded").
                withFormUrlEncodedBody(Application.BookingRef -> "asdf")

            println("before: request." + request.body)
                
            //setup stubs
            Application.someRepository = SomeRepositoryStub
            
            //call method under test
            val asyncResult = Application.someAsync()(request)
            
            //fetch and wait for async result
            val future = asyncResult.run
            val t = Duration(30, "seconds")
            val result = Await.result(future, t)

            //assertions
            try{
                val c = contentAsString(result)
                val s = status(result)
                assertEquals(OK, s)
                assertTrue(c.contains("[Stubbed] You said: asdf"))
            }catch{
                case t: Throwable => {
                    t.printStackTrace()
                    fail(t.getMessage())
                }
            }
        }
    }

    @Test
    def testAsyncGet {

        new WithApplication {
            
            //setup input
            val request = FakeRequest(GET, "/someAsync?bookingRef=asdf").
                withSession(Security.username -> "lana@hippodrome-london.com")

            //setup stubs
            Application.someRepository = SomeRepositoryStub
            
            //call method under test
            val asyncResult = Application.someAsync()(request)
            
            //fetch and wait for async result
            val future = asyncResult.run
            val t = Duration(30, "seconds")
            val result = Await.result(future, t)
                
            //assertions
            try{
                val c = contentAsString(result)
                val s = status(result)
                assertEquals(OK, s)
                assertTrue(c.contains("[Stubbed] You said: asdf"))
            }catch{
                case t: Throwable => {
                    t.printStackTrace()
                    fail(t.getMessage())
                }
            }
        }            
    }    
}

//a stub of the repo, since we want an isolated unit test of the controller
object SomeRepositoryStub extends SomeRepository {
    def doDatabaseCall(s: String) = "[Stubbed] You said: " + s
}