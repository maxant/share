package controllers

import play.api._
import play.api.mvc._
import play.api._
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import java.util.UUID
import play.api.libs.concurrent.Akka
import play.api.Play.current
import play.api.libs.concurrent.Promise
import scala.xml.Elem
import play.api.libs.concurrent.Redeemable
import play.api.libs.ws.WS
import scala.xml.NodeSeq
import java.util.Date
import scala.util._
import backend.SomeRepositoryImpl
import backend.SomeRepository

object Application extends Controller {

    var someRepository: SomeRepository = SomeRepositoryImpl
    val BookingRef = "bookingRef"

    val form = Form(
        BookingRef -> nonEmptyText
    )
    
    def home = Action { request =>
        Ok(views.html.main(request.session.get(Security.username), form))
    }

    def login = Action { request =>
        val name = "John"
        Ok(views.html.main(Some(name), form)).withSession(request.session + (Security.username -> name))
    }
    
    def someAsync = Security.Authenticated(getUsername, onUnauthorized){ username =>
println("a")
        Action{ implicit request => 
println("b session " + request.session)
println("b body " + request.body)
println("b queryString " + request.queryString)
            form.bindFromRequest.fold(
                errors => {
println("c")
                    BadRequest(views.html.main(request.session.get(Security.username), form))
                },
                ref => {
println("d ref " + ref)
                    Async {
println("e")
                        val responseFromWebService = Akka.future{
println("f")
                            val ret = someRepository.doDatabaseCall(ref)
println("g")
                            ret
                        }
println("h")
                        
                        import scala.concurrent.ExecutionContext.Implicits.global
                        
                        responseFromWebService.map{ answer =>
println("i answer " + answer)
                            Ok(views.html.main(Some(answer), form))
                        }
                    }
                }
            )
        }
    }

    private def getUsername(request: RequestHeader) = request.session.get(Security.username)
    
    private def onUnauthorized(request: RequestHeader) = Results.Redirect(controllers.routes.Application.login)
}