package backend

/** an interface, so that the impl can be mocked or stubbed */
object SomeRepositoryImpl extends SomeRepository {

    def doDatabaseCall(s: String): String = {
        //block for a bit like most db drivers
println("j")
        Thread.sleep(30)
println("k")
        "You said: " + s
    }
}