package backend

/** an interface, so that the impl can be mocked or stubbed */
abstract trait SomeRepository {

    def doDatabaseCall(s: String): String
}